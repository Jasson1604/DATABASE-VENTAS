let numero = 42;
let nombre = "Hola Mundo"
let verdadero = true;
let undef;
let nula = null;

console.log(typeof nombre);
console.log(typeof numero);
console.log(typeof verdadero);
console.log(typeof undef);
console.log(typeof nula);
