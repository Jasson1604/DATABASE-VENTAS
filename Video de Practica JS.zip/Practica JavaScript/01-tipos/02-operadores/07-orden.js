let resultado = 8/2*(2+2)
console.log(resultado);
