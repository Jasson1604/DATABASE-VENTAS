let a = 5;
let b = 7;

console.log(a + b); // adicion-suma
console.log(a - b); // resta
console.log(a * b); // multiplicacion
console.log(a / b); // división
console.log(a % b); // porcentaje
console.log(a ** b); // potencia 

// incrementar
console.log(++a);
console.log(a++);
console.log(a);
//decrementar
console.log(--a);
console.log(a--);
console.log(a);
