// Personaje de Television 
let nombre = "Juanito";
let anime = "Dragon Ball"
let edad = 17;

let personaje = {
    nombre: "Juanito",
    anime: "Dragon Ball",
    edad: 17,
};
console.log(personaje);
console.log(personaje.nombre);
console.log(personaje['anime']);

personaje.edad= 14;

let llave = 'edad';
personaje[llave] = 17;

delete personaje.anime;

console.log(personaje);

