let numero = 42;

console. log(numero);