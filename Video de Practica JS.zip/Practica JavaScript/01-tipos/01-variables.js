let nombre = "Hola Mundo";

console.log(nombre);