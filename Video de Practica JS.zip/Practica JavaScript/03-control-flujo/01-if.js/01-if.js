if (condicion){
    expresion
}
let edad = 25;
if (edad > 17) {
    console.log('usuario mayor de edad');
}
    



