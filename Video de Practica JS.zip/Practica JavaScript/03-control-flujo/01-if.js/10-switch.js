let accion = 'listar';

switch (accion) {
    case 'listar':
        console.log('Accion de listar');
        case 'guardar'
        console.log('Accion de Guardar');
        break;
        default:
            console.log('Accion no reconocida');
}