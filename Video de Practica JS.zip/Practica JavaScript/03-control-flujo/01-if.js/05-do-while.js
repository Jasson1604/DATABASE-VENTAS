// cuales son los numeros pares

let i = 0;
while (i < 10) {
    if (1 % 2 == 0) {
        console.log('Numero par', i);
    }
    i++;
}

do {
    if (i % 2 == 0){
        console.log('Numero par', i);
    }
    i++;
} while (i < 3);